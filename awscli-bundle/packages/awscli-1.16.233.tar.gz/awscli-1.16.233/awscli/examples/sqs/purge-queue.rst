**To purge a queue**

This example deletes all messages in the specified queue.

Command::

  aws sqs purge-queue --queue-url https://sqs.us-east-1.amazonaws.com/80398EXAMPLE/MyNewQueue

Output::

  None.